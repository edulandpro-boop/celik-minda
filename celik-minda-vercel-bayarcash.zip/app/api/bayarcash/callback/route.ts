import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase-admin";
import { Bayarcash } from "bayarcash-ts-sdk";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const secret = process.env.BAYARCASH_API_SECRET_KEY;
    const token = process.env.BAYARCASH_API_TOKEN;
    if (!secret || !token) return new NextResponse("Missing gateway configuration", { status: 500 });

    const form = await request.formData();
    const data: Record<string, string> = {};
    form.forEach((value, key) => { data[key] = String(value); });

    const sandbox = process.env.BAYARCASH_SANDBOX !== "false";
    const bayarcash = new Bayarcash(token, { sandbox, apiVersion: "v3" });
    const valid = bayarcash.verifyTransactionCallbackData(data as never, secret);
    if (!valid) return new NextResponse("Invalid checksum", { status: 400 });

    const orderNumber = data.order_number;
    const status = String(data.status ?? "");
    if (!orderNumber) return new NextResponse("Missing order number", { status: 400 });

    // Bayarcash status 3 means successful. Do not trust the browser return URL.
    if (status === "3") {
      const { error } = await supabaseAdmin
        .from("celik_minda_orders")
        .update({ payment_status: "paid", order_status: "confirmed" })
        .eq("order_number", orderNumber)
        .neq("payment_status", "paid");
      if (error) {
        console.error("Order payment update failed:", error.message);
        return new NextResponse("Database update failed", { status: 500 });
      }
    } else if (["2", "4", "5"].includes(status)) {
      await supabaseAdmin
        .from("celik_minda_orders")
        .update({ payment_status: "failed", order_status: "cancelled" })
        .eq("order_number", orderNumber)
        .eq("payment_status", "pending");
    }

    return NextResponse.json({ received: true });
  } catch (error) {
    console.error("Bayarcash callback error:", error instanceof Error ? error.message : "Unknown error");
    return new NextResponse("Callback processing failed", { status: 500 });
  }
}
