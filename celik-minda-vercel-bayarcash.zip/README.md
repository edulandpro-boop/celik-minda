# Celik Minda PASTI — Next.js + Supabase + Bayarcash

Mobile-first green/Islamic-themed storefront for Vercel. Product prices are read from Supabase. Checkout creates an order on the server and redirects the customer to Bayarcash.

## Before deploying

1. Create a Supabase project.
2. Run the SQL schema already supplied in the chat. Ensure the six `celik_minda_products` SKUs exist:
   - `CMA-PDF` RM10
   - `CMA-HC` RM15
   - `CMB-PDF` RM10
   - `CMB-HC` RM15
   - `CMAB-PDF` RM18
   - `CMAB-HC` RM20, includes postage
3. In Bayarcash console, get Personal Access Token and API Secret Key under Profile > Integration, and Portal Key under Portal.
4. Copy `.env.example` to `.env.local` and fill in real credentials. Never commit `.env.local`.
5. Install and test locally:
   ```bash
   npm install
   npm run dev
   ```
6. Push the folder to a private GitHub repository and import it into Vercel, or upload it to an existing project.
7. Add every environment variable from `.env.example` in Vercel Project Settings > Environment Variables. Set `NEXT_PUBLIC_SITE_URL` to the deployed HTTPS URL.
8. Keep `BAYARCASH_SANDBOX=true` while testing. Switch to `false` only after a successful sandbox test and the merchant account is enabled for live transactions.
9. Configure Bayarcash callback URL to `https://YOUR-DOMAIN/api/bayarcash/callback` if your portal configuration requires it.
10. Test the callback and payment status using Bayarcash sandbox before accepting real payments.

## Important

- The Supabase `service_role` key and Bayarcash token/secret are server-only environment variables. Never use them in `NEXT_PUBLIC_*` variables or browser code.
- The callback validates the Bayarcash transaction checksum before changing order status.
- The current callback expects the Bayarcash v3 transaction callback to arrive as form data, as described by the SDK. Confirm with the sandbox payload before production.
- The return page is not proof of payment. The verified server-to-server callback updates the order.
- Confirm your Bayarcash account has FPX enabled. The integration currently requests FPX channel 1.
- The project does not automatically email the customer or deliver the PDF after payment. Add a protected admin/delivery workflow before using this for live sales.
- The page uses an illustrative cover mockup made with CSS; replace it with the real product cover and genuine worksheet previews before publishing.
- No credentials are included in this archive.
